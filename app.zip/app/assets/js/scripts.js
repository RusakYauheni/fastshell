/*!
 * fastshell
 * Fiercely quick and opinionated front-ends
 * https://HosseinKarami.github.io/fastshell
 * @author Hossein Karami
 * @version 1.0.5
 * Copyright 2018. MIT licensed.
 */
(function ($, window, document, undefined) {

  'use strict';

  $(function () {
    // FastShell

$('.slider').sss({
	slideShow : true, // Set to false to prevent SSS from automatically animating.</span>
	startOn : 0, // Slide to display first. Uses array notation (0 = first slide).</span> 
	transition : 400, // Length (in milliseconds) of the fade transition.</span>
	speed : 3500, // Slideshow speed in milliseconds.</span>
	showNav : true // Set to false to hide navigation arrows.</span>
});

  });

})(jQuery, window, document);
